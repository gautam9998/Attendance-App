package com.gautam.haazeeri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class AttendanceListActivity extends AppCompatActivity {


    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_list);

        recyclerView=findViewById(R.id.recycle);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        List<ModelClass> modelClassList=new ArrayList<>();
        modelClassList.add(new ModelClass("Akhansha","40%"));
        modelClassList.add(new ModelClass("PRAGYA","53%"));
        modelClassList.add(new ModelClass("RITWIKA","68%"));
        modelClassList.add(new ModelClass("ANSHU","7%"));
        modelClassList.add(new ModelClass("LOVELY","67%"));

        AdapterClass adapterClass=new AdapterClass(modelClassList);
        recyclerView.setAdapter(adapterClass);
        adapterClass.notifyDataSetChanged();



    }
}

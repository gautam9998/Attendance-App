package com.gautam.haazeeri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MarksActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marks);
        recyclerView=findViewById(R.id.recycle1);




        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        List<ModelClass> modelClassList=new ArrayList<>();
        modelClassList.add(new ModelClass("Anoop","40/50"));
        modelClassList.add(new ModelClass("Benu Bhai","48/50"));
        modelClassList.add(new ModelClass("Nitish jee","32/50"));
        modelClassList.add(new ModelClass("Ankit Patiyal","50/50"));
        modelClassList.add(new ModelClass("Pradeep","absent"));

        AdapterClass adapterClass=new AdapterClass(modelClassList);
        recyclerView.setAdapter(adapterClass);
        adapterClass.notifyDataSetChanged();
    }
}

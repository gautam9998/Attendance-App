package com.gautam.haazeeri;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.Viewholder> {

    List<ModelClass> modelClassList;

    public AdapterClass(List<ModelClass> modelClassList) {
        this.modelClassList = modelClassList;
    }

    @NonNull
    @Override
    public Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout,parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Viewholder holder, int position) {

        String name=modelClassList.get(position).getName();
        String roll=modelClassList.get(position).getRoll();

 holder.setData(name,roll);

    }

    @Override
    public int getItemCount() {
        return modelClassList.size();
    }

    class Viewholder extends RecyclerView.ViewHolder{


        private TextView names,rolls;
        public Viewholder(@NonNull View itemView) {
            super(itemView);

            names=itemView.findViewById(R.id.name);
            rolls=itemView.findViewById(R.id.roll);
        }

        private void setData(String n,String r){
            names.setText(n);
            rolls.setText(r);
        }
    }

}

package com.gautam.haazeeri;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class UpdateInformationActivity extends AppCompatActivity {
    EditText inputName,inputPassword,roll,year;
    String phoneNumber,UserType,saveCurrentDate,saveCurrentTime;
    Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_information);



        Calendar calFordDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("dd-MMMM-yyyy");
        saveCurrentDate = currentDate.format(calFordDate.getTime());

        Calendar calFordTime = Calendar.getInstance();
        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm");
        saveCurrentTime = currentTime.format(calFordDate.getTime());


        phoneNumber = getIntent().getStringExtra("Phone_Number");
        UserType= getIntent().getStringExtra("User_Type");



        inputName=findViewById(R.id.user_name_input);
        inputPassword=findViewById(R.id.user_password_input);
        year=findViewById(R.id.user_year_input);
        roll=findViewById(R.id.user_roll_input);
        submit=findViewById(R.id.submit_btn);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Log.i("wwww","  oooooooo "+ phoneNumber);
                Log.v("kkkk","kkkkk"+phoneNumber);
                Log.v("kkkk","kkhhhhhhhkkk"+UserType);





                //update(year.toString(),roll.toString());

Update();



/*
                DatabaseReference RootRef;
                RootRef = FirebaseDatabase.getInstance().getReference();

                HashMap userdataMap = new HashMap<>();
                userdataMap.put("NAME", inputName.getText().toString());
                userdataMap.put("PASSWORD",inputPassword.getText().toString());
                userdataMap.put("YEAR", year.getText().toString());
                userdataMap.put("ROLL", roll.getText().toString());
                userdataMap.put("USER_TYPE", UserType.toString());
                userdataMap.put("PHONE", phoneNumber.toString());
                userdataMap.put("TIME",saveCurrentDate+" " +saveCurrentTime);
                //userdataMap.put("ATTENDANCE_LIST", list);



                RootRef.child(UserType).child(phoneNumber).updateChildren(userdataMap).addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {


                        if (task.isSuccessful()) {
                            Toast.makeText(UpdateInformationActivity.this, "Attendance Submitted Successfully ...", Toast.LENGTH_SHORT).show();
                            //loadingBar.dismiss();
                            // Intent intent= new Intent(RegisterActivity.this,LoginActivity.class);
                            //  startActivity(intent);
                        } else {
                            Toast.makeText(UpdateInformationActivity.this, "Error , try again ", Toast.LENGTH_SHORT).show();
                            // loadingBar.dismiss();
                        }

                    }
                });

*/






            }












        });


    }












        private void Update()
        {
            final DatabaseReference RootRef;
            RootRef= FirebaseDatabase.getInstance().getReference();
            RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(!dataSnapshot.child(UserType).child(phoneNumber).exists())
                    {

                        HashMap userdataMap = new HashMap<>();
                        userdataMap.put("name", inputName.getText().toString());
                        userdataMap.put("password",inputPassword.getText().toString());
                        userdataMap.put("year", year.getText().toString());
                        userdataMap.put("roll", roll.getText().toString());
                        userdataMap.put("user_type", UserType.toString());
                        userdataMap.put("phone", phoneNumber.toString());
                        userdataMap.put("date&time",saveCurrentDate+" " +saveCurrentTime);
                        //userdataMap.put("ATTENDANCE_LIST", list);


                        final HashMap userdataMap1 = new HashMap<>();
                        userdataMap1.put("name", inputName.getText().toString());
                        userdataMap1.put("password",inputPassword.getText().toString());
                        userdataMap1.put("phone", phoneNumber.toString());




                        RootRef.child(UserType).child(phoneNumber).updateChildren(userdataMap).addOnCompleteListener(new OnCompleteListener() {
                            @Override
                            public void onComplete(@NonNull Task task) {


                                if(task.isSuccessful())
                                {
                                    Toast.makeText(UpdateInformationActivity.this,"Account Created Successfully ...",Toast.LENGTH_SHORT).show();
                                    //loadingBar.dismiss();
                                    Intent intent= new Intent(UpdateInformationActivity.this,Main2Activity.class);
                                    startActivity(intent);

                                    RootRef.child("Users").child(phoneNumber).updateChildren(userdataMap1);
                                    finish();
                                }
                                else
                                {
                                    Toast.makeText(UpdateInformationActivity.this,"Error , try again ",Toast.LENGTH_SHORT).show();
                                   // loadingBar.dismiss();
                                }

                            }
                        });

                    }
                    else
                    {
                        Toast.makeText(UpdateInformationActivity.this,"This "+phoneNumber+" Is Already Registered",Toast.LENGTH_SHORT).show();
                        //loadingBar.dismiss();
                        Toast.makeText(UpdateInformationActivity.this,"Try With New Number ...",Toast.LENGTH_SHORT).show();
                        Intent intent= new Intent(UpdateInformationActivity.this,MainActivity.class);
                        startActivity(intent);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });








        }











}

package com.gautam.haazeeri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import io.paperdb.Paper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gautam.haazeeri.Prevalent.Prevalent;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeDashActivity extends AppCompatActivity {



    ImageView imageView,imageView1;
    String myprofileimage;
    TextView textView;
    Button logout;
    CardView cardView,data,mark,late;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_dash);


     final    String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        String UserPasswordKey = Paper.book().read(Prevalent.UserPasswordKey);
        imageView=findViewById(R.id.attendance);
        cardView=findViewById(R.id.bankcardId);

        textView=findViewById(R.id.welcome);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeDashActivity.this, HomeActivity.class);
                startActivity(intent);
               // finish();





            }
        });


        logout = findViewById(R.id.button1);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeDashActivity.this, Main2Activity.class);
                startActivity(intent);


                Paper.book().destroy();
                finish();
            }
        });




        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();






      /*  RootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                 myprofileimage = dataSnapshot.child("Users").child(UserPhoneKey).child("name").getValue().toString();

                    textView.setText("Welcome  "+ myprofileimage);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/




data=findViewById(R.id.database);
data.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(HomeDashActivity.this, AttendanceListActivity.class);
        startActivity(intent);
        //finish();

    }
});






       mark=findViewById(R.id.marks);
       mark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeDashActivity.this, MarksActivity.class);
                startActivity(intent);
                //finish();

            }
        });



       late=findViewById(R.id.lates);
        late.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeDashActivity.this,LateActivity.class);
                startActivity(intent);
                //finish();

            }
        });


    }

}




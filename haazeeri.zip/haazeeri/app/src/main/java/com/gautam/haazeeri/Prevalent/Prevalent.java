package com.gautam.haazeeri.Prevalent;

import com.gautam.haazeeri.Model.Users;
//import com.example.attendance.Model.Users;


public class Prevalent
{
    private static Users currentOnlineUser;
    public static final  String UserPhoneKey="UserPhone";
    public static final  String UserPasswordKey="UserPassword";
}

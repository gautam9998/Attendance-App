package com.gautam.haazeeri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectUserTypeActivity extends AppCompatActivity {

    Button student, teacher, admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_user_type);


        student = findViewById(R.id.Student_button);
        teacher = findViewById(R.id.Teacher_button);
        admin = findViewById(R.id.Admin_button);




        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectUserTypeActivity.this, MobileActivity.class);
                intent.putExtra("User_Type","STUDENT");
                startActivity(intent);

            }


        });



        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectUserTypeActivity.this, MobileActivity.class);
                intent.putExtra("User_Type","TEACHER");
                startActivity(intent);

            }


        });
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectUserTypeActivity.this, MobileActivity.class);
                intent.putExtra("User_Type","ADMIN");
                startActivity(intent);

            }


        });

    }






}
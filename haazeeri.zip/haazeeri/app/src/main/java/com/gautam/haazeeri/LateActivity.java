package com.gautam.haazeeri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class LateActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_late);
        recyclerView=findViewById(R.id.late);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        List<ModelClass> modelClassList=new ArrayList<>();
        modelClassList.add(new ModelClass("Akhansha",""));
        modelClassList.add(new ModelClass("PRAGYA",""));
        modelClassList.add(new ModelClass("RITWIKA",""));
        modelClassList.add(new ModelClass("ANSHU",""));
        modelClassList.add(new ModelClass("LOVELY",""));
        modelClassList.add(new ModelClass("roshni",""));
        modelClassList.add(new ModelClass("sujit",""));
        modelClassList.add(new ModelClass("abhishek",""));
        modelClassList.add(new ModelClass("amit",""));
        modelClassList.add(new ModelClass("santothi",""));

        AdapterClass adapterClass=new AdapterClass(modelClassList);
        recyclerView.setAdapter(adapterClass);
        adapterClass.notifyDataSetChanged();

    }
}

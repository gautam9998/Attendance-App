package com.gautam.haazeeri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import io.paperdb.Paper;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

public class HomeActivity extends AppCompatActivity {


    private ProgressDialog loadingBar;
    ImageView imageView;
    private String saveCurrentDate, saveCurrentTime;
    TextView abs_list,date;
    String s;
    String selectedSex, selectedAge;
    Button add_to_list_button, remove_from_list_button, submit_list_button,logout;
    EditText input_roll, remove_roll;
    ArrayAdapter<CharSequence> adapterAge;
    ArrayAdapter<CharSequence> adapterSex;

    List<String> roll_list = new ArrayList<>();




    ///////////


    Spinner sp_parent, sp_child;
    ArrayList<String> arrayList_parent, arrayList_I, arrayList_II, arrayList_III, arrayList_IV;
    ArrayAdapter<String> arrayAdapter_parent, arrayAdapter_child;


    ///////////////


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        ///////////
        imageView=findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, InformationActivity.class);


                startActivity(intent);
                //finish();
            }
        });

        sp_parent = (Spinner) findViewById(R.id.spinner);
        sp_child = (Spinner) findViewById(R.id.spinner1);

        arrayList_parent = new ArrayList<>();
        arrayList_parent.add("I");
        arrayList_parent.add("II");
        arrayList_parent.add("III");
        arrayList_parent.add("IV");

        arrayAdapter_parent = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arrayList_parent);
        sp_parent.setAdapter(arrayAdapter_parent);


        arrayList_I = new ArrayList<>();
        arrayList_I.add("BLE");
        arrayList_I.add("BME");
        arrayList_I.add("PSCP");
        arrayList_I.add("EG");


        arrayList_II = new ArrayList<>();
        arrayList_II.add("DATA STRC");
        arrayList_II.add("NETWORKS");
        arrayList_II.add("MATHS 3");
        arrayList_II.add("DIGITAL");

        arrayList_III = new ArrayList<>();
        arrayList_III.add("OOPS");
        arrayList_III.add("HTML");
        arrayList_III.add("ML");
        arrayList_III.add("AI");


        arrayList_IV = new ArrayList<>();
        arrayList_IV.add("SEMINAR");
        arrayList_IV.add("PROJECT");
        arrayList_IV.add("VISIT");
        arrayList_IV.add("INTERVIEW");


        sp_child.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (selectedAge == "I" && position == 0) {
                    selectedSex = "BLE";
                }
                if (selectedAge == "I" && position == 1) {
                    selectedSex = "BME";
                }
                if (selectedAge == "I" && position == 2) {
                    selectedSex = "PSCP";
                }
                if (selectedAge == "I" && position == 3) {
                    selectedSex = "EG";

                }
                if (selectedAge == "II" && position == 0) {
                    selectedSex = "DATA STRUCRURE";

                }
                if (selectedAge == "II" && position == 1) {
                    selectedSex = "NETWORKS";

                }
                if (selectedAge == "II" && position == 2) {
                    selectedSex = "MATHS 3";

                }
                if (selectedAge == "II" && position == 3) {
                    selectedSex = "DIGITAL";

                }

                if (selectedAge == "III" && position == 0) {
                    selectedSex = "OOPs";

                }
                if (selectedAge == "III" && position == 1) {
                    selectedSex = "HTML";

                }
                if (selectedAge == "III" && position == 2) {
                    selectedSex = "ML";

                }
                if (selectedAge == "III" && position == 3) {
                    selectedSex = "AI";

                }
                if (selectedAge == "IV" && position == 0) {
                    selectedSex = "SEMINAR";

                }
                if (selectedAge == "IV" && position == 1) {
                    selectedSex = "PROJECT";

                }
                if (selectedAge == "IV" && position == 2) {
                    selectedSex = "VISIT";

                }
                if (selectedAge == "IV" && position == 3) {
                    selectedSex = "INTERVIEW";

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp_parent.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    selectedAge = "I";
                    arrayAdapter_child = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList_I);
                }
                if (position == 1) {
                    selectedAge = "II";
                    arrayAdapter_child = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList_II);
                }
                if (position == 2) {
                    selectedAge = "III";
                    arrayAdapter_child = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList_III);
                }
                if (position == 3) {
                    selectedAge = "IV";
                    arrayAdapter_child = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item, arrayList_IV);
                }
                sp_child.setAdapter(arrayAdapter_child);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        add_to_list_button = findViewById(R.id.add);

        logout = findViewById(R.id.button);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Main2Activity.class);
                startActivity(intent);


                Paper.book().destroy();
                finish();
            }
        });



        submit_list_button = findViewById(R.id.submit);


        loadingBar = new ProgressDialog(this);

        input_roll = findViewById(R.id.add_txt);

        abs_list = findViewById(R.id.absents);
        date = findViewById(R.id.textView4);

        Calendar calFordDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("dd-MMMM-yyyy");
        saveCurrentDate = currentDate.format(calFordDate.getTime());

        Calendar calFordTime = Calendar.getInstance();
        SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm");
        saveCurrentTime = currentTime.format(calFordDate.getTime());

        date.setText("Attendance for "+saveCurrentDate);





        add_to_list_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String r = input_roll.getText().toString();
                input_roll.setText("");

                if (r.isEmpty()) {
                    Toast.makeText(HomeActivity.this, "INSERT ABSENTEES ROLL", Toast.LENGTH_LONG).show();

                } else {
                    //input_roll.setText("");

                    roll_list.add(r);
                    Toast.makeText(HomeActivity.this, r, Toast.LENGTH_LONG).show();
                    if (s == null) {
                        s = r;

                    } else {
                        s = s + "," + r;

                    }

                    abs_list.setText( "Absents : " +s);
                }
            }
        });


        submit_list_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(HomeActivity.this, "ssssssssss    " + selectedAge + "     " + selectedSex, Toast.LENGTH_LONG).show();
                submitAttendance(selectedAge,selectedSex,saveCurrentDate,saveCurrentTime,s);
                // AppCompatActivity.REC
                abs_list.setText("");
                roll_list.clear();

           Intent intent =new Intent(HomeActivity.this,HomeDashActivity.class);
           startActivity(intent);
                // abs_list.cl

            }
        });

    }


    private void submitAttendance(final String year, final String subject, final String date, final String time, final String list) {
        final DatabaseReference RootRef;
        RootRef = FirebaseDatabase.getInstance().getReference();
        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("Users").exists()) {

                    HashMap userdataMap = new HashMap<>();
                    userdataMap.put("YEAR", year);
                    userdataMap.put("SUBJECT", subject);
                    userdataMap.put("DATE", date);
                    userdataMap.put("TIME", time);
                    userdataMap.put("ATTENDANCE_LIST", list);
                    RootRef.child("Users").child("Attendance").child(year).child(subject).child(date).child(time).updateChildren(userdataMap).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {


                            if (task.isSuccessful()) {
                                Toast.makeText(HomeActivity.this, "Attendance Submitted Successfully ...", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                                // Intent intent= new Intent(RegisterActivity.this,LoginActivity.class);
                                //  startActivity(intent);
                            } else {
                                Toast.makeText(HomeActivity.this, "Error , try again ", Toast.LENGTH_SHORT).show();
                                loadingBar.dismiss();
                            }

                        }
                    });

                } else {
                    // Toast.makeText(HomeActivity.this,"This "+phone+" Is Already Registered",Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                    Toast.makeText(HomeActivity.this, "Try With New Number ...", Toast.LENGTH_SHORT).show();
                    //  Intent intent= new Intent(RegisterActivity.this,MainActivity.class);
                    //startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }
        });


    }


}




